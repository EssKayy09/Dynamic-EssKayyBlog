-- Dummy Data for EssKayyBlog

-- Users
INSERT INTO users (username, email, password, full_name, role) VALUES
('admin', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin User', 'admin'),
('jane_doe', 'jane@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Jane Doe', 'editor');

-- Categories
INSERT INTO categories (name, slug, description) VALUES
('Culture', 'culture', 'Articles about culture and life.'),
('Business', 'business', 'Business news and tips.'),
('Lifestyle', 'lifestyle', 'Lifestyle advice and trends.'),
('Technology', 'technology', 'Latest tech news.');

-- Posts
INSERT INTO posts (title, slug, excerpt, content, image_url, category_id, user_id, status, is_featured, is_trending, views, created_at) VALUES
('The Best Homemade Masks for Face', 'best-homemade-masks', 'Keep the pimples away with these masks.', 'Full content about homemade masks...', 'assets/img/post-slide-1.jpg', 3, 2, 'published', 1, 1, 120, NOW()),
('17 Pictures of Medium Length Hair', 'medium-length-hair', 'Inspire your new haircut with these styles.', 'Full content about hair...', 'assets/img/post-slide-2.jpg', 1, 2, 'published', 1, 1, 95, NOW()),
('13 Amazing Poems from Shel Silverstein', 'amazing-poems', 'Valuable life lessons from poems.', 'Full content about poems...', 'assets/img/post-slide-3.jpg', 1, 2, 'published', 1, 0, 150, NOW()),
('9 Half-up/half-down Hairstyles', 'half-up-half-down', 'Hairstyles for long and medium hair.', 'Full content about hairstyles...', 'assets/img/post-slide-4.jpg', 1, 2, 'published', 1, 0, 80, NOW()),
('11 Work From Home Part-Time Jobs', 'wfh-jobs', 'Jobs you can do now.', 'Content about WFH jobs...', 'assets/img/post-landscape-1.jpg', 2, 1, 'published', 0, 1, 200, NOW()),
('Let’s Get Back to Work, New York', 'back-to-work-ny', 'Returning to office life.', 'Content about NY work...', 'assets/img/post-landscape-2.jpg', 2, 1, 'published', 0, 0, 50, NOW()),
('How to Avoid Distraction', 'avoid-distraction', 'Stay focused during video calls.', 'Content about focus...', 'assets/img/post-landscape-5.jpg', 3, 1, 'published', 0, 1, 300, NOW());
