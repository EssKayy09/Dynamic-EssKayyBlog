<?php
$db_user = "root";
$db_password = "";
$db_name = "esskayyblog";

$db_connection = mysqli_connect("localhost", $db_user, $db_password, $db_name);

if (!$db_connection) {
    die("Connection failed: " . mysqli_connect_error());
}
