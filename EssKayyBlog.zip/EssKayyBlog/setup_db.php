<?php
$host = "localhost";
$user = "root";
$pass = "";

// 1. Connect to MySQL Server
try {
    $conn = new mysqli($host, $user, $pass);
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    echo "Connected to MySQL server successfully.\n";

    // 2. Create Database
    $db_name = "esskayyblog";
    $sql = "CREATE DATABASE IF NOT EXISTS $db_name";
    if ($conn->query($sql) === TRUE) {
        echo "Database '$db_name' created or already exists.\n";
    } else {
        throw new Exception("Error creating database: " . $conn->error);
    }

    // 3. Select Database
    $conn->select_db($db_name);

    // 4. Import Schema
    $schema_sql = file_get_contents('db/schema.sql');
    if ($conn->multi_query($schema_sql)) {
        do {
            if ($result = $conn->store_result()) {
                $result->free();
            }
        } while ($conn->next_result());
        echo "Schema imported successfully.\n";
    } else {
        throw new Exception("Error importing schema: " . $conn->error);
    }

    // 5. Import Dummy Data (only if table empty to avoid dupes/errors on re-run, or just try/catch unique constraint)
    // Simple verification check: count posts
    $result = $conn->query("SELECT COUNT(*) as count FROM posts");
    $row = $result->fetch_assoc();
    if ($row['count'] == 0) {
        $dummy_sql = file_get_contents('db/dummy_data.sql');
        if ($conn->multi_query($dummy_sql)) {
            do {
                if ($result = $conn->store_result()) {
                    $result->free();
                }
            } while ($conn->next_result());
            echo "Dummy data imported successfully.\n";
        } else {
            echo "Error importing dummy data (might be expected if partial): " . $conn->error . "\n";
        }
    } else {
        echo "Posts table already has data. Skipping dummy data import.\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    exit(1);
}
