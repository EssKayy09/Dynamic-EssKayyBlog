<?php
include 'db_connection.php';

if ($db_connection) {
    echo "Connected successfully.\n";

    // Get tables
    $tables_result = mysqli_query($db_connection, "SHOW TABLES");
    if ($tables_result) {
        while ($row = mysqli_fetch_row($tables_result)) {
            $table_name = $row[0];
            echo "Table: $table_name\n";

            // Get columns for each table
            $columns_result = mysqli_query($db_connection, "DESCRIBE $table_name");
            if ($columns_result) {
                while ($col = mysqli_fetch_assoc($columns_result)) {
                    echo "  - " . $col['Field'] . " (" . $col['Type'] . ")\n";
                }
            }
        }
    } else {
        echo "Error listing tables: " . mysqli_error($db_connection);
    }
} else {
    echo "Connection failed.\n";
}
